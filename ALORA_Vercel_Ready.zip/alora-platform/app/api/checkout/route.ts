import { NextRequest, NextResponse } from 'next/server';
import { createOrder } from '@/lib/orders/createOrder';
import { getPaymentProvider } from '@/lib/payments/provider';

/**
 * POST /api/checkout
 *
 * Body: {
 *   userId, idempotencyKey, items[], shippingAddress,
 *   paymentProvider: 'paymob' | 'pi_network',
 *   customer: { email, firstName, lastName, phone }
 * }
 *
 * Flow: create the order atomically (reserves stock) → ask the chosen
 * payment provider for a checkout URL → return that URL to the front-end.
 * If anything fails after the order is created but before payment starts,
 * the order simply sits in `pending_payment` — nothing is lost, and the
 * customer (or a scheduled job) can retry payment against the same order.
 */
export async function POST(req: NextRequest) {
  const body = await req.json();

  const {
    userId,
    idempotencyKey,
    items,
    shippingAddress,
    paymentProvider,
    customer,
  } = body;

  if (!userId || !idempotencyKey || !items?.length || !shippingAddress || !paymentProvider) {
    return NextResponse.json({ error: 'Missing required checkout fields' }, { status: 400 });
  }

  let order;
  try {
    order = await createOrder({ userId, idempotencyKey, items, shippingAddress });
  } catch (err: any) {
    // Stock problems and duplicate submissions both land here — return a
    // 409 (conflict) rather than a generic error so the front-end can show
    // "this item just sold out" instead of a scary failure message.
    return NextResponse.json({ error: err.message }, { status: 409 });
  }

  // Pi Network's flow is client-initiated (see lib/payments/piNetwork.ts) —
  // for that provider, return the order so the front-end's Pi SDK can start
  // the payment itself, instead of expecting a checkoutUrl.
  if (paymentProvider === 'pi_network') {
    return NextResponse.json({ order, checkoutUrl: null, requiresClientSdk: true });
  }

  try {
    const provider = getPaymentProvider(paymentProvider);
    const intent = await provider.createIntent({
      orderId: order.id,
      amount: order.total,
      currency: order.currency as 'EGP' | 'USD',
      customer,
      redirectUrl: `${process.env.PUBLIC_SITE_URL}/orders/${order.id}/confirmation`,
    });

    return NextResponse.json({ order, checkoutUrl: intent.checkoutUrl });
  } catch (err: any) {
    // The order already exists (stock is reserved) — it stays in
    // pending_payment and the customer can retry payment, instead of the
    // reservation being silently lost.
    return NextResponse.json(
      { order, error: `Payment could not be started: ${err.message}` },
      { status: 502 }
    );
  }
}
