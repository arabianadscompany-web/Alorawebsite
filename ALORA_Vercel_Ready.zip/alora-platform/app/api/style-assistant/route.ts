import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

// ============================================================================
// POST /api/style-assistant
//
// This is the server-side half of the contract defined in the front-end
// (`callLLMStyleAssistant()` / `buildStyleAssistantRequest()` /
// `parseStyleAssistantResponse()` in the site's <script> block). Keep the
// request/response shapes here in sync with those functions if either side
// changes.
//
// Request body:  { answers: QuizAnswers, locale: string }
// Response body: { styleSummary: string, recommendations: RecommendationItem[] }
// ============================================================================

const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_ANON_KEY!);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY!;

interface QuizAnswers {
  occasion: string;
  colorMood: string;
  fit: string;
  budget: string;
  vibe: string;
}

interface CatalogProduct {
  id: string;
  title: string;
  price: number;
  category_id: string | null;
  description: string | null;
}

interface RecommendationItem {
  productId: string;
  reason: string;
}

interface StyleAssistantResponse {
  styleSummary: string;
  recommendations: RecommendationItem[];
}

// Human-readable labels for each answer id — mirrors SA_QUESTIONS in the
// front-end exactly, so the prompt reads naturally to the LLM instead of
// sending it raw ids like "budgetMid".
const ANSWER_LABELS: Record<string, Record<string, string>> = {
  occasion: {
    casual: 'Everyday Casual',
    office: 'Work & Office',
    evening: 'Evening Glam',
    romantic: 'Romantic Date',
  },
  colorMood: {
    pink: 'Soft Blush & Pink',
    gold: 'Gold & Neutral',
    deep: 'Bold & Deep Tones',
    classic: 'Classic Black & White',
  },
  fit: {
    flowy: 'Flowy & Relaxed',
    fitted: 'Fitted & Sleek',
    oversized: 'Oversized & Comfy',
    structured: 'Structured & Tailored',
  },
  budget: {
    budgetLow: 'Under 500 EGP',
    budgetMid: '500–1,500 EGP',
    budgetHigh: '1,500–3,000 EGP',
    budgetAny: 'No limit',
  },
  vibe: {
    newIn: 'New In Trendsetter',
    dailyChic: 'Daily Chic',
    softRomance: 'Soft Romance',
    bestSellers: 'Best Sellers Fan',
  },
};

export async function POST(req: NextRequest) {
  let body: { answers: QuizAnswers; locale?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const { answers } = body;
  if (!answers || !answers.occasion || !answers.colorMood || !answers.fit || !answers.budget || !answers.vibe) {
    return NextResponse.json({ error: 'Missing required quiz answers' }, { status: 400 });
  }

  // Pull the live, active catalog — keep this reasonably small (cap below)
  // since the entire list is sent to the LLM as context.
  const { data: products, error } = await supabase
    .from('products')
    .select('id, title, price, category_id, description')
    .eq('status', 'active')
    .limit(60);

  if (error) {
    return NextResponse.json({ error: `Failed to load catalog: ${error.message}` }, { status: 500 });
  }

  if (!products || products.length === 0) {
    return NextResponse.json(
      { error: 'No active products available to recommend from' },
      { status: 503 }
    );
  }

  try {
    const result = await getRecommendationsFromLLM(answers, products);
    return NextResponse.json(result);
  } catch (err: any) {
    return NextResponse.json({ error: `Style Assistant failed: ${err.message}` }, { status: 502 });
  }
}

/* ---------------------------------------------------------------------------
   PROMPT ENGINEERING
   --------------------------------------------------------------------------- */

function buildSystemPrompt(): string {
  return [
    'You are the AI Style Assistant for Alora, a fashion e-commerce marketplace.',
    'You recommend products from the exact catalog list provided to you — never invent products that are not in the list.',
    'You must respond with strictly valid JSON matching this TypeScript shape, and nothing else (no markdown, no commentary outside the JSON):',
    '{ "styleSummary": string, "recommendations": Array<{ "productId": string, "reason": string }> }',
    '- "styleSummary" is one or two warm, specific sentences describing the customer\'s style based on their answers.',
    '- "recommendations" must contain between 3 and 5 items.',
    '- Every "productId" must be the exact `id` field of a product from the catalog list given to you.',
    '- Every "reason" is one short sentence (under 20 words) explaining why that specific product fits this specific customer.',
    '- Prioritize products whose price fits the customer\'s stated budget band; if nothing fits perfectly, pick the closest reasonable matches rather than returning fewer than 3 items.',
  ].join('\n');
}

function buildUserPrompt(answers: QuizAnswers, products: CatalogProduct[]): string {
  const answerLines = (Object.keys(answers) as Array<keyof QuizAnswers>)
    .map((key) => `- ${key}: ${ANSWER_LABELS[key]?.[answers[key]] ?? answers[key]}`)
    .join('\n');

  const catalogLines = products
    .map((p) => `- id: ${p.id} | title: ${p.title} | price: ${p.price} EGP | description: ${p.description ?? 'n/a'}`)
    .join('\n');

  return [
    'Customer quiz answers:',
    answerLines,
    '',
    'Available catalog (recommend ONLY from this list, using the exact id values):',
    catalogLines,
    '',
    'Return the JSON object described in your instructions now.',
  ].join('\n');
}

/* ---------------------------------------------------------------------------
   LLM CALL + RESPONSE VALIDATION
   --------------------------------------------------------------------------- */

async function getRecommendationsFromLLM(
  answers: QuizAnswers,
  products: CatalogProduct[]
): Promise<StyleAssistantResponse> {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      response_format: { type: 'json_object' },
      temperature: 0.7,
      messages: [
        { role: 'system', content: buildSystemPrompt() },
        { role: 'user', content: buildUserPrompt(answers, products) },
      ],
    }),
  });

  if (!res.ok) {
    throw new Error(`LLM request failed (${res.status}): ${await res.text()}`);
  }

  const completion = await res.json();
  const rawContent: string | undefined = completion?.choices?.[0]?.message?.content;
  if (!rawContent) {
    throw new Error('LLM returned no content');
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(rawContent);
  } catch {
    throw new Error('LLM response was not valid JSON');
  }

  return validateAndCleanResponse(parsed, products);
}

/**
 * Never trust an LLM's output shape blindly — this validates every field,
 * drops any recommended productId that isn't actually in the catalog (the
 * model can hallucinate ids despite instructions), and guarantees the
 * function either returns a genuinely usable response or throws clearly.
 */
function validateAndCleanResponse(parsed: unknown, products: CatalogProduct[]): StyleAssistantResponse {
  if (typeof parsed !== 'object' || parsed === null) {
    throw new Error('LLM response is not an object');
  }

  const obj = parsed as Record<string, unknown>;

  if (typeof obj.styleSummary !== 'string' || obj.styleSummary.trim().length === 0) {
    throw new Error('LLM response missing a valid styleSummary');
  }

  if (!Array.isArray(obj.recommendations)) {
    throw new Error('LLM response missing a recommendations array');
  }

  const validProductIds = new Set(products.map((p) => p.id));

  const recommendations: RecommendationItem[] = obj.recommendations
    .filter((r: unknown): r is { productId: unknown; reason: unknown } =>
      typeof r === 'object' && r !== null
    )
    .map((r: any) => ({ productId: String(r.productId ?? ''), reason: String(r.reason ?? '') }))
    .filter((r) => validProductIds.has(r.productId) && r.reason.length > 0);

  if (recommendations.length === 0) {
    throw new Error('LLM did not return any recommendations matching the real catalog');
  }

  return {
    styleSummary: obj.styleSummary,
    recommendations: recommendations.slice(0, 5),
  };
}
