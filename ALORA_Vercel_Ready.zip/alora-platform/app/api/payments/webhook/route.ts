import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { getPaymentProvider } from '@/lib/payments/provider';
import { assertValidTransition, OrderStatus } from '@/lib/orders/stateMachine';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

/**
 * POST /api/payments/webhook?provider=paymob
 *
 * This is the single most important route for "no technical errors cause a
 * transfer to not arrive." Every payment provider calls this URL to confirm
 * what actually happened — the front-end redirect alone is NOT trustworthy
 * (a customer can close the tab, lose connection, or the redirect can be
 * spoofed), so the order is only ever marked "paid" from here, after
 * signature verification.
 *
 * Safe to receive the same webhook twice (providers retry on timeout):
 *   1. verifyWebhook() checks the signature — invalid signatures are
 *      rejected outright (prevents anyone from faking a "payment succeeded"
 *      call).
 *   2. The `payments` table has a UNIQUE(provider, provider_reference)
 *      constraint (see db/schema.sql) — inserting the same confirmation
 *      twice fails harmlessly on the second attempt instead of crediting
 *      the order twice.
 *   3. assertValidTransition() refuses to move an already-"paid" (or
 *      "refunded") order backwards if a stale/duplicate webhook arrives
 *      out of order.
 */
export async function POST(req: NextRequest, { params }: { params: { provider: string } }) {
  const providerId = req.nextUrl.searchParams.get('provider') ?? params?.provider;
  if (!providerId) {
    return NextResponse.json({ error: 'Missing provider' }, { status: 400 });
  }

  const rawBody = await req.text();
  const headers = Object.fromEntries(req.headers.entries());

  const provider = getPaymentProvider(providerId);
  const result = await provider.verifyWebhook(rawBody, headers);

  if (!result.isValid) {
    // Do not reveal *why* it failed — just reject. Log server-side for
    // investigation instead.
    console.error(`[webhook] Invalid signature from provider=${providerId}`);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
  }

  if (!result.orderId || !result.providerReference) {
    console.error(`[webhook] Missing orderId/providerReference`, result);
    return NextResponse.json({ error: 'Malformed webhook payload' }, { status: 400 });
  }

  // Step 1: record the payment attempt. The unique constraint on
  // (provider, provider_reference) makes this line the idempotency
  // boundary — a retried webhook simply fails this insert and we stop here.
  const { error: insertError } = await supabase.from('payments').insert({
    order_id: result.orderId,
    provider: providerId,
    provider_reference: result.providerReference,
    amount: result.amount,
    currency: 'EGP',
    status: result.status,
    raw_payload: result.rawPayload,
  });

  if (insertError) {
    if (insertError.code === '23505') {
      // Postgres unique-violation code — we've already processed this exact
      // confirmation before. Returning 200 tells the provider "got it,
      // don't retry" without touching the order again.
      return NextResponse.json({ ok: true, duplicate: true });
    }
    console.error('[webhook] Failed to record payment', insertError);
    return NextResponse.json({ error: 'Internal error recording payment' }, { status: 500 });
  }

  // Step 2: move the order's status, going through the state machine so an
  // out-of-order or stale webhook can never corrupt a later, more-advanced
  // order state.
  if (result.status === 'success') {
    const { data: order } = await supabase
      .from('orders')
      .select('status')
      .eq('id', result.orderId)
      .single();

    if (order) {
      try {
        assertValidTransition(order.status as OrderStatus, 'paid');
        await supabase.from('orders').update({ status: 'paid' }).eq('id', result.orderId);
        // TODO: trigger order-confirmation email / seller notification here.
      } catch (e) {
        // Not a failure of the webhook itself — just means this order was
        // already past "paid" (e.g. a duplicate success webhook arriving
        // after a refund). Logged, not thrown, so the provider still gets 200.
        console.warn('[webhook] Ignored out-of-order transition', e);
      }
    }
  } else if (result.status === 'failed') {
    await supabase
      .from('orders')
      .update({ status: 'payment_failed' })
      .eq('id', result.orderId)
      .eq('status', 'pending_payment'); // only touch it if still pending — never overwrite a later state
  }

  return NextResponse.json({ ok: true });
}
