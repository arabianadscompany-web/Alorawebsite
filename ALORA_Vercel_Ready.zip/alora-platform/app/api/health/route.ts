import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    ok: true,
    service: 'alora-platform',
    timestamp: new Date().toISOString(),
  });
}
