import { MetadataRoute } from 'next';
import { createClient } from '@supabase/supabase-js';

// ============================================================================
// Auto-generated sitemap — Next.js serves this at /sitemap.xml automatically.
// It stays correct with zero manual work because it reads directly from the
// live `products` and `categories` tables, instead of being a hand-maintained
// static file that goes stale the moment a product is added or removed.
// ============================================================================

const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_ANON_KEY!);
const SITE_URL = process.env.PUBLIC_SITE_URL ?? 'https://alora-lac-zeta.vercel.app';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [{ data: products }, { data: categories }] = await Promise.all([
    supabase.from('products').select('slug, created_at').eq('status', 'active'),
    supabase.from('categories').select('slug'),
  ]);

  const staticPages: MetadataRoute.Sitemap = [
    { url: SITE_URL, changeFrequency: 'daily', priority: 1 },
    { url: `${SITE_URL}/shop`, changeFrequency: 'daily', priority: 0.9 },
  ];

  const productPages: MetadataRoute.Sitemap = (products ?? []).map((p) => ({
    url: `${SITE_URL}/products/${p.slug}`,
    lastModified: p.created_at,
    changeFrequency: 'weekly',
    priority: 0.8,
  }));

  const categoryPages: MetadataRoute.Sitemap = (categories ?? []).map((c) => ({
    url: `${SITE_URL}/categories/${c.slug}`,
    changeFrequency: 'weekly',
    priority: 0.7,
  }));

  return [...staticPages, ...categoryPages, ...productPages];
}
