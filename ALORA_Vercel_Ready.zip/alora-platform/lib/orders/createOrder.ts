import { createClient } from '@supabase/supabase-js';

// Service-role client: required because create_order() needs to lock and
// write across tables on the user's behalf. Never expose this key to the
// browser — it must only ever be used in server-side code (API routes).
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export interface CreateOrderInput {
  userId: string;
  idempotencyKey: string;
  items: Array<{ productId: string; variantId: string; quantity: number }>;
  shippingAddress: Record<string, unknown>;
  currency?: 'EGP' | 'USD';
}

export interface CreatedOrder {
  id: string;
  status: string;
  subtotal: number;
  total: number;
  currency: string;
}

/**
 * The ONLY correct way to create an order. Delegates the actual stock
 * locking + insert to the `create_order` Postgres function (db/schema.sql),
 * so the all-or-nothing guarantee lives in the database transaction, not in
 * application code that could fail halfway through.
 *
 * `idempotencyKey` should be generated client-side once per checkout attempt
 * (e.g. a UUID stored in the checkout form's hidden state) and reused on any
 * automatic retry — this is what makes double-submitting "Place Order" safe.
 */
export async function createOrder(input: CreateOrderInput): Promise<CreatedOrder> {
  const { data, error } = await supabase.rpc('create_order', {
    p_user_id: input.userId,
    p_idempotency_key: input.idempotencyKey,
    p_items: input.items.map((i) => ({
      product_id: i.productId,
      variant_id: i.variantId,
      quantity: i.quantity,
    })),
    p_shipping_address: input.shippingAddress,
    p_currency: input.currency ?? 'EGP',
  });

  if (error) {
    // Common, expected failure: insufficient stock — surface it clearly so
    // the API route can return a friendly "out of stock" response instead
    // of a generic 500.
    throw new Error(`Order creation failed: ${error.message}`);
  }

  return data as CreatedOrder;
}
