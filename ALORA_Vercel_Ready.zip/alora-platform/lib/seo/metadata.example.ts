// ============================================================================
// EXAMPLE: how a product page should generate its <title>/<meta description>
// and structured data. Drop this pattern into app/products/[slug]/page.tsx
// once that route exists.
// ============================================================================

import type { Metadata } from 'next';
import { productJsonLd, ProductForSeo } from './jsonld';

const SITE_URL = process.env.PUBLIC_SITE_URL ?? 'https://alora-lac-zeta.vercel.app';

// Next.js calls this automatically for the page at the matching route —
// this is what makes each product's search-result snippet unique and
// accurate instead of every page sharing one generic title.
export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const product = await getProductBySlug(params.slug); // fetch from Supabase

  return {
    title: `${product.title} | Alora`,
    description: product.description.slice(0, 155), // Google truncates around here anyway
    openGraph: {
      title: product.title,
      description: product.description,
      images: product.images,
      url: `${SITE_URL}/products/${product.slug}`,
    },
    alternates: { canonical: `${SITE_URL}/products/${product.slug}` },
  };
}

// Example page component showing where the JSON-LD script tag goes.
export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await getProductBySlug(params.slug);

  return (
    <>
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productJsonLd(product, SITE_URL)) }}
      />
      {/* ...actual page UI... */}
    </>
  );
}

async function getProductBySlug(slug: string): Promise<ProductForSeo> {
  // TODO: replace with a real Supabase query once the products table has data.
  throw new Error('not implemented — wire this to Supabase');
}
