import type { PaymentProvider } from './types';
import { paymobProvider } from './paymob';
import { piNetworkProvider } from './piNetwork';

// ============================================================================
// This is the ONE file to touch when a new payment provider is approved
// (a bank's own gateway, Stripe, etc). Write a new file implementing
// PaymentProvider (copy paymob.ts as a template), then register it here.
// Nothing in the checkout flow or webhook route needs to change.
// ============================================================================

const providers: Record<string, PaymentProvider> = {
  paymob: paymobProvider,
  pi_network: piNetworkProvider,
};

export function getPaymentProvider(providerId: string): PaymentProvider {
  const provider = providers[providerId];
  if (!provider) {
    throw new Error(`Unknown payment provider: ${providerId}`);
  }
  return provider;
}

export function listAvailableProviders(): string[] {
  return Object.keys(providers);
}
