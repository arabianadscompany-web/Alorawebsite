// ============================================================================
// Paymob provider.
//
// Why Paymob specifically: as of writing, Paymob is a single, Central
// Bank of Egypt–licensed aggregator that covers card payments (Visa/
// Mastercard/Meeza), Vodafone Cash/Orange Cash/other mobile wallets, AND
// Fawry — all under one merchant account and one API. That means the
// "Fawry or Vodafone Cash or Visa & Mastercard" approval the business is
// planning to apply for is very likely ALL Paymob, just different
// "integration IDs" inside the same Paymob dashboard. Confirm this with
// Paymob directly when you apply, but it is why this file alone may cover
// every payment method the business wants.
//
// ⚠️ IMPORTANT — READ BEFORE GOING LIVE:
// Paymob's exact field names for the Intention API request/response and
// the exact webhook HMAC field order are set by Paymob and can change.
// This file is structured correctly and the HMAC verification PATTERN is
// correct (HMAC-SHA512 over a fixed, documented field order, compared
// against the `hmac` query param), but you must confirm the current field
// list against Paymob's live "Developer Reference → Webhooks" page at
// https://developers.paymob.com/paymob-docs before processing real money.
// Every place that needs that confirmation is marked with a TODO below.
// ============================================================================

import crypto from 'crypto';
import type {
  PaymentProvider,
  PaymentIntentRequest,
  PaymentIntentResult,
  WebhookResult,
} from './types';

const PAYMOB_BASE_URL = process.env.PAYMOB_BASE_URL ?? 'https://accept.paymob.com'; // Egypt region
const PAYMOB_SECRET_KEY = process.env.PAYMOB_SECRET_KEY!;       // from Paymob dashboard
const PAYMOB_PUBLIC_KEY = process.env.PAYMOB_PUBLIC_KEY!;       // from Paymob dashboard
const PAYMOB_HMAC_SECRET = process.env.PAYMOB_HMAC_SECRET!;     // from Paymob dashboard
// Integration IDs: one per payment method you enable in the Paymob dashboard
// (card, wallet, Fawry). Add one env var per method you get approved for.
const PAYMOB_INTEGRATION_IDS = (process.env.PAYMOB_INTEGRATION_IDS ?? '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

export const paymobProvider: PaymentProvider = {
  id: 'paymob',

  async createIntent(request: PaymentIntentRequest): Promise<PaymentIntentResult> {
    if (PAYMOB_INTEGRATION_IDS.length === 0) {
      throw new Error(
        'PAYMOB_INTEGRATION_IDS is empty — add at least one integration id from the Paymob dashboard before accepting live payments.'
      );
    }

    // Paymob's modern "Intention API" — one call creates the payment
    // intention and returns a client_secret used to build the checkout URL.
    // TODO: confirm this exact request shape against Paymob's current
    // "Intention API" reference before go-live; amount handling in
    // particular (Paymob has historically expected amounts in the
    // currency's smallest unit, e.g. piastres for EGP — multiply by 100
    // if the current docs still require that).
    const res = await fetch(`${PAYMOB_BASE_URL}/v1/intention/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Token ${PAYMOB_SECRET_KEY}`,
      },
      body: JSON.stringify({
        amount: Math.round(request.amount * 100), // TODO: confirm smallest-unit requirement against current docs
        currency: request.currency,
        payment_methods: PAYMOB_INTEGRATION_IDS,
        billing_data: {
          email: request.customer.email,
          first_name: request.customer.firstName,
          last_name: request.customer.lastName,
          phone_number: request.customer.phone,
        },
        extras: { order_id: request.orderId },
        redirection_url: request.redirectUrl,
      }),
    });

    if (!res.ok) {
      const body = await res.text();
      throw new Error(`Paymob createIntent failed (${res.status}): ${body}`);
    }

    const data = await res.json();

    return {
      // TODO: confirm the exact checkout-URL construction against current
      // docs — Paymob has used both a returned `payment_keys` iframe URL
      // and a unified checkout URL built from `client_secret` + public key
      // depending on integration type. The shape below follows the unified
      // checkout pattern; adjust if the live docs show otherwise.
      checkoutUrl: `${PAYMOB_BASE_URL}/unifiedcheckout/?publicKey=${PAYMOB_PUBLIC_KEY}&clientSecret=${data.client_secret}`,
      providerReference: data.id?.toString() ?? data.intention_order_id?.toString(),
    };
  },

  async verifyWebhook(rawBody: string, headers: Record<string, string>): Promise<WebhookResult> {
    const payload = JSON.parse(rawBody);
    const obj = payload.obj ?? payload; // Paymob nests transaction data under `obj` in legacy webhooks

    // TODO: confirm this exact field list and order against Paymob's current
    // "Webhooks → HMAC Calculation" docs before go-live. Historically Paymob
    // concatenates a fixed, documented set of transaction fields (amount_cents,
    // created_at, currency, error_occured, has_parent_transaction, id,
    // integration_id, is_3d_secure, is_auth, is_capture, is_refunded,
    // is_standalone_payment, is_voided, order.id, owner, pending,
    // source_data.pan, source_data.sub_type, source_data.type, success)
    // in that exact order, HMAC-SHA512-signs it with PAYMOB_HMAC_SECRET, and
    // sends the result as the `hmac` query param on the webhook URL. Re-derive
    // `fieldsInOrder` below from the live docs before trusting this in production.
    const fieldsInOrder: string[] = [
      // placeholder — replace with the confirmed, documented field order
    ];
    const concatenated = fieldsInOrder.map((f) => String(getNestedField(obj, f) ?? '')).join('');
    const computedHmac = crypto
      .createHmac('sha512', PAYMOB_HMAC_SECRET)
      .update(concatenated)
      .digest('hex');

    const receivedHmac = headers['hmac'] ?? new URL(headers['x-original-url'] ?? '', 'http://x').searchParams.get('hmac') ?? '';
    const isValid = fieldsInOrder.length > 0 && timingSafeEqual(computedHmac, receivedHmac);

    return {
      isValid,
      orderId: obj?.order?.merchant_order_id ?? obj?.extras?.order_id ?? null,
      providerReference: obj?.id?.toString() ?? null,
      status: obj?.success ? 'success' : obj?.pending ? 'pending' : 'failed',
      amount: obj?.amount_cents ? obj.amount_cents / 100 : null,
      rawPayload: payload,
    };
  },
};

function getNestedField(obj: any, path: string): unknown {
  return path.split('.').reduce((acc, key) => (acc == null ? acc : acc[key]), obj);
}

/** Constant-time string comparison — prevents timing attacks on signature checks. */
function timingSafeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}
