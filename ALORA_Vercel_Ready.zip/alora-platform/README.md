# Alora Platform — Start Here

This package is a complete handoff for building Alora into a real,
production-grade, multi-vendor fashion marketplace. It is meant to be given
to an AI coding assistant (or a developer) to implement.

**If you are the AI/developer implementing this: read the files in this
exact order before writing any code.**

## Reading order

1. **`SPEC.md`** — the full product specification. Read **Section 1 (Honest
   Scope Note)** and **Section 11 (Open Decisions Needed From the Business
   Owner)** first — they define what "professional, like Amazon and Shein"
   actually means for this project (system stability, correct payments, no
   double-bookings — NOT literal feature parity with those companies), and
   what business-side information you must get from the owner before some
   work can proceed (payment processor approval, real product data, legal
   policy text, shipping partner).
2. **`PAYMENTS_AND_SEO_README.md`** — the payments and SEO engineering that
   is already built and working in this package (not just specified). Read
   this before touching anything under `lib/payments/`, `lib/orders/`, or
   `lib/seo/` — it explains *why* each piece exists and which TODOs must be
   resolved against live provider docs before go-live.
3. **`reference/alora-current-site.html`** — the current, deployed,
   approved visual design. Its colors, fonts, and layout are the source of
   truth for every page you build — do not redesign it.
4. **`db/schema.sql`** — run this in Supabase before writing any page that
   touches data. Every table and the `create_order()` function are
   referenced directly by the code in `lib/`.

## What is already built (working code, not placeholders)

- ✅ Database schema with transaction-safe, overselling-proof order creation
- ✅ Payment provider abstraction (`lib/payments/`) — Paymob (cards + wallets
  + Fawry) and Pi Network, both implementing one shared interface
- ✅ Checkout API route and payment webhook handler, with idempotency and a
  strict order-status state machine — this is the part that guarantees "no
  technical errors cause a lost transfer or a booking mix-up"
- ✅ Technical SEO: JSON-LD structured data, auto-generated sitemap.xml and
  robots.txt, correct per-page metadata pattern

## What is NOT built yet (your job, in this order — see SPEC.md Section 9)

1. Migrate `reference/alora-current-site.html`'s design into actual Next.js
   pages (homepage, product listing, product detail, cart, checkout UI,
   account pages) wired to the Supabase tables in `db/schema.sql`.
2. Customer auth (Supabase Auth — signup/login/account pages).
3. Seller signup + seller dashboard (product management, order view).
4. Admin dashboard (seller approvals, `site_content` management — this is
   also the real, permanent replacement for the current hero-cover-photo
   feature, which today only saves to one visitor's own browser).
5. AI Style Assistant (SPEC.md Section 5.4).
6. Full SEO pass once real pages/products exist (apply the patterns in
   `lib/seo/` to every page).

## Setup

```bash
npm install
cp .env.example .env.local   # then fill in real values
# Run db/schema.sql in the Supabase SQL editor before starting the app
npm run dev
```

## A note on honesty with the business owner

If, while implementing, something in `SPEC.md` turns out to be unrealistic
in the timeframe or budget available, say so plainly and propose the
nearest achievable alternative — don't silently under-build while implying
full scope was delivered. This matches how the spec itself was written.

## Current handoff status

The approved `alora-homepage final.html` has been preserved as `public/alora.html` and is served at the root route through the Next.js shell. The original visual design is the source of truth; do not redesign it while implementing backend functionality.
