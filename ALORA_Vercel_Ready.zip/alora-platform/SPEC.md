# Alora — Full-Stack Build Specification & Handoff Brief

> **ملاحظة للمستخدم:** الملف ده مكتوب بالإنجليزي لأنه مستند تقني هيتسلم لنموذج ذكاء اصطناعي تاني أو مبرمج ينفذ بيه — الإنجليزي بيقلل سوء الفهم في المصطلحات التقنية. اقرأ قسم **"Honest Scope Note"** و**"Open Decisions Needed From You"** قبل ما تحوله لأي حد، لأنهم أهم جزئين بيوضحوا الواقعي والمش واقعي، والحاجات اللي محتاجة قرار منك إنت شخصيًا.

---

## 0. How To Use This Document

This file is a **handoff brief**, not a finished codebase. Give it to whichever AI assistant or developer builds the next phase. It should:
1. Read this entire document first.
2. Ask the business owner (the person who gave it this file) the questions in **Section 11** before writing code.
3. Build in the phased order given in **Section 9** — not everything at once.
4. Treat **Section 1 (Honest Scope Note)** as binding: do not silently over-promise Amazon/Shein-level scope in one pass.

A working front-end file (`alora-current-site.html`) is attached alongside this brief — it is the current, deployed, static prototype. Its design tokens, copy, and layout are the source of truth for visual style.

---

## 1. Honest Scope Note (read this first)

The request behind this brief was: *"make it professional like Amazon and Shein, with full backend, correct database, AI servers for SEO, so it spreads fast."* Before building anything, the following must be understood and communicated back to the business owner:

- **Amazon and Shein are multi-billion-dollar engineering operations** with thousands of engineers, warehouses, logistics networks, and decades of data. No single build — by any AI or small team — reaches that scale or feature parity. That is not a limitation of effort; it is a difference in kind, not degree.
- What **is** realistically achievable: a **professional, functioning, multi-vendor e-commerce marketplace MVP** — real accounts, real product database, real cart/checkout, real payments, a seller dashboard, an admin dashboard, and solid technical SEO. This is a legitimate, valuable, buildable product. It should be scoped and presented to the owner as that, not as "Amazon-level," so expectations stay accurate.
- **"AI servers that support SEO and make the site spread fast"** is not a real category of product. SEO improves ranking through: (a) technical correctness (server-rendered pages, fast load times, structured data, sitemaps, mobile performance), and (b) content and backlinks over time. AI can help generate product copy and metadata, but no AI service makes a brand-new site "spread fast" by itself — that also requires marketing spend, social presence, or paid ads, which is a business activity outside of code. Section 8 lists what AI can legitimately do here.
- Every "free" tool/tier named in this document is real and has a genuine free tier as of this writing, but all free tiers have limits (requests/month, storage caps, etc.) that an implementer must check at build time, since they change.

---

## 1.5 Priority Clarification From the Business Owner (read this second)

The owner has clarified what "like Amazon and Shein" actually means for this project, and it is **narrower and more concrete** than Section 1 first assumed — this is good news, because it is fully achievable. In the owner's own words, the priority is:

- **System stability** — no technical errors.
- **No payment failures** — a customer is never charged without a confirmed order, and never has an order confirmed without a confirmed payment.
- **No booking/order mix-ups** — stock and orders stay consistent even under concurrent traffic.
- **Multi-vendor selling with commission** — sellers list products, the platform takes a cut automatically on each sale.
- **A payment-ready codebase** — the owner is separately applying for merchant accounts with **Fawry, Vodafone Cash, and Visa/Mastercard** using the company's paperwork. The code must be fully built and tested in sandbox/test mode **before** those approvals arrive, so that once approved, connecting the real payment provider is a configuration step (swap test keys for live keys, pick which adapter to enable) — **not a development project**.

This reframes the brief: the top engineering priority is **Section 6 (architecture) and the new Section 6A below**, not AI/SEO polish. Sections 5.4 (AI) and 8 (SEO) remain valid but are lower priority than getting payments and order integrity correct and provably reliable.

**One important practical note for the owner, worth confirming directly with each provider before filing three separate applications:** in the Egypt market, payment aggregators such as **Paymob** typically offer Visa/Mastercard, Fawry, and mobile wallets including Vodafone Cash **under a single merchant integration and a single API**, rather than requiring three separate technical integrations. This does not remove the need for business paperwork/KYC, and it should be verified directly with Paymob (or Fawry's own direct gateway, if preferred) at application time since merchant terms change — but it means the "one adapter, multiple providers" architecture in Section 6A below may end up needing only one real adapter instead of three, which simplifies both the paperwork and the code. Build the abstraction either way, since it costs nothing extra and removes risk if the providers are used separately after all.

---

## 2. Current State

- **Live URL:** `https://alora-lac-zeta.vercel.app`
- **Repository:** GitHub — `arabianadscompany-web/Alora-website`, branch `main`, file `index.html`
- **Hosting:** Vercel, connected to the GitHub repo (auto-deploys on commit to `main`)
- **Stack today:** a single static HTML file — vanilla HTML/CSS/JavaScript, no framework, no backend, no database. All "data" (prices, stats, seller names) is hardcoded text in the HTML.
- **Known live bug at time of writing:** the last manual copy-paste edit (done via GitHub's mobile web editor) resulted in the deployed page rendering as unstyled plain text — the `<style>` block likely got corrupted in the mobile copy/paste (common cause: iOS smart-quotes substitution breaking CSS syntax, or a partial paste). **The implementer's first task should be to verify `index.html` on the `main` branch renders correctly, and if not, replace it wholesale with the attached `alora-current-site.html`.**
- **What exists functionally today:** a homepage UI only (hero, shop-the-look section, category grid, lookbook, two promo cards, trust badges, seller logos strip, newsletter form, footer). A client-side-only "hero cover photo" upload feature was added that saves the image to the visitor's own browser `localStorage` — this is explicitly a placeholder/preview feature, not a real shared feature, and should be replaced by a real admin-managed cover image once the backend exists (Section 6).
- **What does NOT exist today:** user accounts, a product database, a real cart, checkout, payments, a seller onboarding flow, an admin panel, search, reviews, order history, email notifications, or any server-side code at all.

---

## 3. Brand & Design System (source of truth)

Pull these exact values from `alora-current-site.html`'s `<style>` block — do not redesign from scratch.

**Color tokens:**
```
--white:        #ffffff
--pink-50:      #fff8fb
--pink-100:     #ffedf4
--pink-200:     #ffdcea
--pink-300:     #ffc3dd
--pink-400:     #ffa8cd
--pink-deep:    #f477ae
--pink-deep-2:  #e85f9c
--gold-200:     #fbf0d3
--gold-400:     #e7c27f
--gold-500:     #d4a656
--gold-600:     #b3813a
--ink:          #6d3c58
--ink-strong:   #552d43
--ink-soft:     #a47b96
```

**Typography:**
- Headings / logo script: `Playfair Display` and `Cormorant Garamond` (italic), via Google Fonts
- Body / UI text: `Poppins`

**Brand identity:** "Alora" — soft pink, white, and gold-metallic e-commerce fashion brand, tagline *"Curated for Every Version of You"*. Logo is a transparent PNG with gold script text, a gold butterfly, and a pink ribbon, embedded in the current HTML as a base64 data URI. Tone: feminine, delicate, premium ("Barbie-soft" was the owner's own description), never dark/heavy — avoid reintroducing the earlier dark-burgundy palette that was explicitly rejected during design iteration.

**Icon style:** custom inline SVGs styled as glossy 3D gold-metallic badges (radial-gradient + inset shadow technique) — reuse this `.icon-badge` pattern for any new icons rather than importing a generic icon font, to keep visual consistency.

---

## 4. Current Page Inventory (homepage only)

1. Announcement top bar (free shipping threshold, track order, help center, sell-on-Alora link)
2. Sticky nav: currency selector (EGP), category links, logo, search/account/wishlist/cart icons, cart count badge
3. Hero: cover-photo area (currently local-only upload), logo, headline, subtext, two CTAs, stats row (10K+ customers / 500+ sellers / 20K+ styles / 4.9 rating)
4. "Shop the Look" — an outfit with 4 add-on tags and a bundled-price summary card
5. Category grid — 4 cards (New In / Daily Chic / Soft Romance / Best Sellers)
6. Lookbook — 3-image strip
7. Two promo cards — "AI Style Assistant" and "Sell on Alora"
8. Trust-badge row (Curated with Love / Trusted Sellers / Exclusive Collection / Easy Shopping / Safe & Secure)
9. Horizontal scrolling trusted-sellers logo strip (6 placeholder brand names)
10. Newsletter signup band
11. Footer (shop/customer-care/about link columns, payment icons, copyright)

None of these are wired to real data yet — all of Section 6 onward exists to make them real.

---

## 5. Target Feature Set

### 5.1 Customer-facing
- Account creation / login (email + password, plus optionally Google/Apple OAuth)
- Product catalog browsing, filtering, and search
- Product detail pages (images, variants — size/color, price, stock, seller, reviews)
- Cart (persisted to the account/database, not just in-browser)
- Checkout: shipping address, shipping method, order summary
- Payments: card payment (see 5.5) and Pi Network payment as an alternate method
- Order history and order status tracking
- Wishlist (persisted)
- Product reviews and ratings
- Newsletter subscription (persisted to a real mailing list, see Section 8)

### 5.2 Seller-facing ("Sell on Alora")
- Seller signup/application flow with basic KYC fields (business name, contact, payout details)
- Seller dashboard: add/edit products, manage stock, view orders for their products, view payouts
- Multi-vendor order splitting (one customer order can contain items from multiple sellers)

### 5.3 Admin-facing
- Approve/reject seller applications
- Manage categories, featured products/sections (so the homepage's "Shop the Look," category grid, and lookbook become editable instead of hardcoded)
- Manage the hero cover image for real (replacing the current localStorage-only placeholder) — this is the direct real version of what the owner asked for
- View all orders, basic sales reporting
- Manage coupons/discounts

### 5.4 AI features (realistic scope)
- **AI Style Assistant** (already a promo card on the homepage): a chat or quiz-style tool that recommends products from the real catalog based on a few questions. Implementation: call an LLM API (OpenAI, Anthropic, or an open-source model on a free-tier inference host) with the user's answers plus a filtered slice of the product catalog, and have it return recommended product IDs. This is buildable and genuinely useful.
- **AI-assisted SEO content**: use an LLM to draft product meta-descriptions, alt text for product images, and category copy — a human (or the AI) should still review output before publishing, since AI-generated SEO text can be repetitive or inaccurate.
- **What AI cannot do**: guarantee rankings, fabricate traffic, or replace the technical SEO work in Section 8. Treat any plan that promises this with the same skepticism applied in Section 1.

### 5.5 Payments
- **Card payments:** needs a real payment processor with Egypt/MENA support, e.g. **Paymob** or **Fawry** (local), or **Stripe** (if the business entity qualifies for Stripe's supported countries). This requires real business KYC with the processor — not something code alone can satisfy (see Section 11).
- **Pi Network payments:** integrate the Pi SDK (already scoped in earlier project discussion) so Pi can be offered as an alternate payment method at checkout, clearly labeled as a secondary/experimental payment option given Pi's price volatility (discussed earlier in this project) — do not make it the only payment method.

---

## 6. Recommended Technical Architecture

| Layer | Recommendation | Why |
|---|---|---|
| Frontend framework | **Next.js (React)** | Needed for server-side rendering, which the current static HTML cannot do and which real SEO requires (Section 8). Can reuse the existing CSS design tokens and markup almost directly. |
| Backend | **Next.js API routes** (or a separate Node/Express service if the team prefers a split repo) | Keeps one deployable unit on Vercel; avoids standing up a second server for an MVP. |
| Database | **PostgreSQL via Supabase** | Free tier is genuinely usable for an MVP, includes auth, storage, and row-level security out of the box — saves building auth and file storage from scratch. |
| Auth | **Supabase Auth** | Handles customer, seller, and admin roles via role claims; free tier is sufficient for MVP user volumes. |
| Image/file storage | **Supabase Storage** | Same provider as the DB, free tier is enough for an MVP product catalog. |
| Search | Start with **Postgres full-text search** (built into Supabase); migrate to **Algolia** or **Meilisearch** free/self-hosted tier only once catalog size makes it necessary. | Avoids adding a paid dependency before it's needed. |
| Hosting | **Vercel** (already in use) | No change needed; Next.js is Vercel's native framework. |
| Email (order confirmations, seller notifications) | **Resend** or **Supabase's built-in email** | Both have workable free tiers for low volume. |

This stack keeps the project on **free tiers for the MVP stage** end-to-end (Vercel + Supabase + Resend), which directly serves the "free" requirement in the original ask — but every free tier has caps, and the implementer should document those caps and the upgrade path once the store has real traffic.

---

## 7. Database Schema (minimum viable entities)

```
users            (id, email, password_hash/auth_id, role[customer|seller|admin], created_at)
sellers          (id, user_id, business_name, status[pending|approved|rejected], payout_info, created_at)
products         (id, seller_id, title, description, price, currency, stock, category_id, images[], status, created_at)
categories       (id, name, slug, parent_id)
product_variants (id, product_id, size, color, stock, price_override)
carts            (id, user_id)
cart_items       (id, cart_id, product_id, variant_id, quantity)
orders           (id, user_id, status, total, shipping_address, payment_method, created_at)
order_items      (id, order_id, product_id, seller_id, quantity, price_at_purchase)
reviews          (id, product_id, user_id, rating, comment, created_at)
wishlists        (id, user_id, product_id)
coupons          (id, code, discount_type, discount_value, expires_at)
newsletter_subs  (id, email, subscribed_at)
site_content     (id, key, value)   -- for admin-editable homepage sections: hero cover image, featured "Shop the Look" bundle, category-grid cards, lookbook images
```

`site_content` is what turns today's hardcoded homepage sections (hero cover, shop-the-look bundle, category cards, lookbook images, trusted-seller logos) into admin-editable data — this is the real, persistent version of the cover-photo feature the owner asked for.

---

## 8. Technical SEO Requirements (concrete, not hype)

1. **Server-side rendering** of all product and category pages (why Next.js is recommended in Section 6) — static-HTML-only sites with client-rendered content are weaker for SEO.
2. **Structured data**: add `schema.org/Product` JSON-LD to every product page (price, availability, rating) — this is what enables rich search results.
3. **Sitemap.xml and robots.txt**, auto-generated from the live product/category database, resubmitted on change.
4. **Per-page meta titles/descriptions**, unique per product and category (AI-assisted drafting is reasonable here, per Section 5.4).
5. **Core Web Vitals**: image optimization (Next.js `<Image>` component), lazy-loading below the fold, minimal JS blocking render.
6. **Canonical URLs** and clean slugs (`/products/satin-blouse`, not query-string IDs) for every product/category.
7. **Mobile performance** — already a strength of the current design; keep it.

None of this guarantees ranking or "fast spread" — it removes the technical reasons a site would rank *worse* than it otherwise could. Ranking well still depends on content quality, backlinks, and time.

---

## 9. Suggested Phased Roadmap

Do not attempt all of this in one pass — each phase should be a working, deployable increment.

**Phase 1 — Foundation**
- Migrate the static HTML to Next.js, preserving the exact design (Section 3)
- Set up Supabase project: auth, database schema (Section 7), storage
- Rebuild the homepage sections to read from `site_content` and `products` instead of hardcoded text

**Phase 2 — Core commerce**
- Product listing/detail pages, cart, checkout (card payment only), order history
- Customer account pages

**Phase 3 — Marketplace**
- Seller signup/dashboard, multi-vendor order splitting
- Admin dashboard (approvals, content management, basic reporting)

**Phase 4 — Differentiators**
- AI Style Assistant
- Pi Network payment option at checkout
- Reviews, wishlist, coupons
- Technical SEO pass (Section 8)

**Phase 5 — Polish & launch readiness**
- Legal pages (terms, privacy, returns policy — see Section 11)
- Load testing, error monitoring (e.g., Sentry free tier)
- Analytics (e.g., Vercel Analytics or Plausible free tier)

---

## 10. Realistic Expectations Summary (for the business owner)

- A working, professional multi-vendor marketplace MVP (Phases 1–3) is a genuinely achievable, multi-week project even with AI-assisted development — not a same-day output.
- "Like Amazon and Shein" should be understood as **"operating on the same basic principles as Amazon and Shein, at a scale appropriate to a new store,"** not feature-for-feature parity.
- Ongoing costs will appear once free tiers are exceeded (database storage, image bandwidth, email volume, search) — budget for this rather than assuming the project stays $0 forever.

---

## 11. Open Decisions Needed From the Business Owner

Before the implementer can finish Phases 2 and beyond, the owner needs to provide or decide:

1. **Payment processor**: which one, and is there a registered business entity to complete its KYC/merchant onboarding? (Paymob and Fawry are the common Egypt-market choices; this cannot be skipped by code.)
2. **Actual product inventory**: real products, prices, images, and stock — or a dropshipping/supplier arrangement — since the current catalog is all placeholder data.
3. **Legal pages content**: a real returns/refund policy, terms of service, and privacy policy (template language exists, but policy specifics — return window, who pays return shipping, etc. — are business decisions).
4. **Shipping**: which courier(s) serve the business, and their rate structure.
5. **Domain**: confirm the `alora.com` purchase status (raised earlier in this project) or the fallback domain to use in production.
6. **Pi Network's role**: confirm it stays a secondary/optional payment method rather than the store's primary funding mechanism, given the price-volatility and platform risk already discussed earlier in this project.

---

## 12. Attached Reference File

`alora-current-site.html` — the current, deployed static prototype. Treat its visual design as final/approved; treat its lack of backend as the entire reason this brief exists.
