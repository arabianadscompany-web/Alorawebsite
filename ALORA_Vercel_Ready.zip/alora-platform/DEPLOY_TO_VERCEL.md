# ALORA — Vercel deployment

This package keeps the approved ALORA homepage design intact in `public/alora.html` and exposes it at `/` through the Next.js shell. Existing API routes remain available under `/api/*`.

## 1. Upload

Upload this entire project folder to GitHub and import the repository into Vercel, or use Vercel's CLI from this folder.

## 2. Environment variables

Set the variables from `.env.example` in Vercel Project Settings → Environment Variables.

For the AI Style Assistant, the required server variables are:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `OPENAI_API_KEY`
- `PUBLIC_SITE_URL`

For payments, add the provider credentials listed in `.env.example` only after the corresponding merchant accounts are approved.

## 3. Database

Run `db/schema.sql` in the Supabase SQL editor before using real checkout/order flows.

## 4. Important scope

The current homepage is the approved visual source of truth and has not been redesigned. The existing browser interactions and AI Style Assistant remain in the page. The Next.js API layer included in this package is the foundation for connecting real Supabase catalog data, checkout and payments.
