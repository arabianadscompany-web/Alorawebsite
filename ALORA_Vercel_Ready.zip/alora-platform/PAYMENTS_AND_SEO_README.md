# Alora Backend Starter — Payments & SEO Readiness

This folder is the direct answer to one request: **make the site technically
ready so that once Fawry / Vodafone Cash / Visa & Mastercard approval comes
through (via Paymob), you only need to add the payment provider's
credentials — not rebuild anything.**

It also implements correct, working technical SEO (structured data, sitemap,
robots.txt) rather than a vague promise of it.

## What's actually in here

```
db/schema.sql                        Database schema + the atomic create_order() function
lib/payments/types.ts                The provider-agnostic interface every payment method implements
lib/payments/paymob.ts               Paymob integration (cards + wallets + Fawry — see note below)
lib/payments/piNetwork.ts            Pi Network integration (secondary/optional payment method)
lib/payments/provider.ts             Registry — the one file to edit to add a future provider
lib/orders/stateMachine.ts           Enforces valid order-status transitions only
lib/orders/createOrder.ts            Calls the atomic DB function — the only correct way to create an order
app/api/checkout/route.ts            API route: reserve stock + create order + start payment
app/api/payments/webhook/route.ts    API route: the ONLY place an order is ever marked "paid"
lib/seo/jsonld.ts                    schema.org Product structured data
lib/seo/metadata.example.ts          Example of correct per-page <title>/<meta> + JSON-LD wiring
app/sitemap.ts                       Auto-generated sitemap.xml from the live database
app/robots.ts                        Auto-generated robots.txt
```

## Why one Paymob integration likely covers all three approvals you're
## planning to apply for

Paymob is a single, Central Bank of Egypt–licensed payment aggregator that
supports card payments (Visa/Mastercard/Meeza) **and** Fawry **and** mobile
wallets (Vodafone Cash, Orange Cash, etc.) under one merchant account —
different "integration IDs" inside one Paymob dashboard, not three separate
integrations. **Confirm this directly with Paymob when you apply**, since
account setup specifics can differ, but it means `lib/payments/paymob.ts` is
very likely the only provider file this project needs for cards + Fawry +
wallets combined.

## Exactly what you do once approval arrives (the whole point of this setup)

1. Get your **API Secret Key**, **Public Key**, **HMAC Secret**, and one
   **Integration ID per payment method** (card / wallet / Fawry) from the
   Paymob dashboard.
2. Add them as environment variables in Vercel (Project → Settings →
   Environment Variables):
   ```
   PAYMOB_SECRET_KEY=...
   PAYMOB_PUBLIC_KEY=...
   PAYMOB_HMAC_SECRET=...
   PAYMOB_INTEGRATION_IDS=12345,12346,12347
   ```
3. In the Paymob dashboard, set your webhook URL to:
   `https://<your-domain>/api/payments/webhook?provider=paymob`
4. **Before accepting real money**, open `lib/payments/paymob.ts` and resolve
   the three `TODO` comments against Paymob's *current* live docs
   (developers.paymob.com) — specifically the Intention API's exact request
   shape and the webhook HMAC field order. These were deliberately left as
   confirm-before-launch items rather than guessed, because getting a
   payment signature check wrong is a security issue, not a cosmetic one.
5. Test everything against Paymob's **sandbox** credentials first — do not
   point live keys at this code without a full test checkout (success path
   AND a deliberately-failed card) confirmed working end to end.

That's the entire "add the payment provider" step. No other file in this
project should need to change.

## What makes this "no technical errors, no lost transfers, no mix-ups"
## (the actual engineering guarantees here)

- **Orders can't oversell**: `create_order()` in `db/schema.sql` locks each
  product's stock row (`FOR UPDATE`) before decrementing it, inside one
  database transaction. Two customers buying the last item at the same
  second cannot both succeed.
- **Checkout can't double-charge or double-create an order**: every checkout
  attempt carries an `idempotency_key`; retrying (network blip, double-tap)
  returns the existing order instead of creating a second one.
- **Webhooks can't be replayed to double-credit an order**: the `payments`
  table has a `UNIQUE(provider, provider_reference)` constraint — Paymob (or
  any provider) retrying the same confirmation fails harmlessly on the
  second attempt.
- **An order's status can't move backwards or get corrupted by an
  out-of-order webhook**: `stateMachine.ts` is the only code path allowed to
  change `orders.status`, and it refuses invalid transitions (e.g. a stale
  "success" webhook arriving after a refund).
- **A failed payment can't silently lose the order**: if payment fails after
  the order/stock reservation succeeds, the order stays visible in
  `pending_payment` / `payment_failed` — nothing disappears, and the
  customer or an admin can retry.

## What this starter deliberately does NOT include yet

This is the payments + SEO foundation specifically, not the whole platform.
Still needed before a real store can run on this: the actual Next.js
pages/UI wired to these APIs, the seller dashboard, the admin dashboard, and
the business-side steps (Paymob merchant approval, real product catalog,
shipping setup) listed in `alora-full-build-spec.md` from the previous
handoff document. Treat that document's phased roadmap (Section 9) as the
order to build the remaining pieces in.
